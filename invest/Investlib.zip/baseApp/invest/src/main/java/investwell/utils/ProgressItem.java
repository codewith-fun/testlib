package investwell.utils;

public class ProgressItem {
    public int color;
    public double progressItemPercentage;
}