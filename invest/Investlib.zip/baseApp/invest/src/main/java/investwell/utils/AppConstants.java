package investwell.utils;

public interface AppConstants {
    String LOGIN_COME_FROM="login_come_from";
    String COME_FROM="coming_from";
    String LOGIN_FOR_REGISTRATION="login_screen_for_registration";
    String LOGIN_FROM_DIRECT="direct_from_login";
    String APP_LANGUAGE="Language";
    String CUSTOMER_ID="Cid";
    String REQUEST_FORMAT="FormatReq";
    String PASSKEY="Passkey";
    String KEY_BROKER_ID ="Bid";
    String KEY_USERNAME="Username";
    String KEY_USER_PASSWORD="Password";
    String APP_BID ="10153";
    String APP_USERNAME ="naikAIwealth25";
    String APP_PASSWORD ="hu45d^48@TY$qaz";
    String INVEST_VIA_LUMPSUM="lumpsum";
    String INVEST_VIA_SIP="Sip";

}
