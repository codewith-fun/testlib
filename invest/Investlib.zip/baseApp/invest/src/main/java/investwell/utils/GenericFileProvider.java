package investwell.utils;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
