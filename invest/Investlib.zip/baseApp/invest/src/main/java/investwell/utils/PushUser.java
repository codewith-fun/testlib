package investwell.utils;

/**
 * Created by BLiveInHack on 8/7/2015.
 */
public class PushUser {
    public static String TOKEN="gcm_id";
    public static String DEVICE_NAME="device_name";
    public static String DEVICE_MODEL="device_model";
    public static String DEVICE_OS="device_os";
    public static String DEVICE_API="device_api";
    public static String LAST_LAT="last_lat";
    public static String LAST_LONG="last_long";
    public static String MEMORY="device_memory";
    public static String DEVICE_ID="device_id";
    public static String PIN_CODE="pin_code";
    public static String TIMEZONE="timezone";
    public static String EMAIL="email";
    public static String APP_TYPE="app_type";
    public static String API_KEY="api_key";

}
