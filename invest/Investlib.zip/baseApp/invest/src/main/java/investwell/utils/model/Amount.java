package investwell.utils.model;

public class Amount {
    private String amount;



    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }
}
