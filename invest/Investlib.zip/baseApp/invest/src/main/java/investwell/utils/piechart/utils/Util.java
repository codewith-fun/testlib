package investwell.utils.piechart.utils;

import java.util.List;

/**
 * Created by 大灯泡 on 2017/11/7.
 */

public class Util {
    public static boolean isListEmpty(List<?> datas) {
        return datas == null || datas.size() <= 0;
    }
}
