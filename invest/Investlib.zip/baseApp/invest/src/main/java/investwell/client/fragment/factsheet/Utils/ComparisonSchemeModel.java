package investwell.client.fragment.factsheet.Utils;

public class ComparisonSchemeModel {
    private String schemeAge;

    public String getSchemeAge() {
        return schemeAge;
    }

    public void setSchemeAge(String schemeAge) {
        this.schemeAge = schemeAge;
    }

    public ComparisonSchemeModel(String schemeAge) {
        this.schemeAge = schemeAge;
    }
}
